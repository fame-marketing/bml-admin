const mysql = require('mysql2'),
      winston = require('../bin/winston')
;

class Database {

  constructor() {

    this.pool = mysql.createPool({
      connectionLimit: 5,
      host: process.env.dbHost,
      user: process.env.dbUser,
      database: process.env.dbName,
      password: process.env.dbPass
    });

    this.promisePool = this.pool.promise();

  }

  /*
   | @query -- a string containing the query base
   | @values -- an object that will be parsed into the query automatically to populate the db column.
  */
  async writePool(query, values) {
    try {
      const [rows, fields] = await this.promisePool.query(query, values);
      return rows;
    } catch (err) {
      winston.error(err);
    }
  }

  /*
   | @query -- a string
   | a non promise version of the db query
  */
  QueryOnly(query) {
    this.pool.query(query, function (err, rows, fields) {
      if (err) throw err;
    })
  }

  /*
   | @query -- a string
   | a query that is intended to handle read tasks or other types of queries that will have a returned value.
  */
  async readPool(query) {

    const [rows, fields] = await this.promisePool.query(query);
    return rows;

  }

}

module.exports = Database;